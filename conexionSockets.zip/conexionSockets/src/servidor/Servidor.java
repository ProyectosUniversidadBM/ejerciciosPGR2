package servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
	
	public static void main(String[] args) {
		
		ServerSocket servidor = null;
		Socket sc = null;
		DataInputStream in;
		DataOutputStream out;
		
		final int PORT = 5000;
		
		try 
		{
			int contador = 0;
			servidor = new ServerSocket(PORT);
			while(true)
			{
				
				System.out.println("Esperando clientes");
				sc = servidor.accept();
				
				System.out.println("Cliente conectado");
				
				in = new DataInputStream(sc.getInputStream());
				out = new DataOutputStream(sc.getOutputStream());
				
				String mensaje = in.readUTF();
				System.out.println(mensaje);
				
				contador++;
				
				System.out.println(sc+"  -  Cliente No. "+contador);
				
				out.writeUTF("Hola, bienvenido al servidor de prueba desde el puerto "+sc.getPort()+", al cliente "+contador+", no mames disfrutalo alv");
				
			} 
		} 
		catch (IOException e) {
			// TODO: handle exception
		}
		
	}

}
