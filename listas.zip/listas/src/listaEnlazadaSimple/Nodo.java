package listaEnlazadaSimple;

public class Nodo {
	
	private int dato;
	private Nodo enlace;
	
	public Nodo(int pdato)
	{
		dato = pdato;
		enlace = null;
	}

	public int getDato() {
		return dato;
	}

	public void setDato(int dato) {
		this.dato = dato;
	}

	public Nodo getEnlace() {
		return enlace;
	}

	public void setEnlace(Nodo enlace) {
		this.enlace = enlace;
	}

}
