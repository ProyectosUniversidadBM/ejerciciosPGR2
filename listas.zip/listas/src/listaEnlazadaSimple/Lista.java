package listaEnlazadaSimple;

public class Lista {
	
	private Nodo primero;
	private Nodo ultimo;
	
	public Lista()
	{
		primero = null;
		ultimo = null;
	}
	
	

	public Nodo getUltimo() {
		return ultimo;
	}



	public void setUltimo(Nodo ultimo) {
		this.ultimo = ultimo;
	}



	public Nodo getPrimero() {
		return primero;
	}

	public void setPrimero(Nodo primero) {
		this.primero = primero;
	}
	
	public Lista insertarComienzo(int pdato)
	{
		Nodo g;
		g = new Nodo(pdato);
		if(ultimo != null)
		{
			g.setEnlace(primero);
			primero = g;
			return this;
		}
		else
		{
			g.setEnlace(primero);
			primero = g;
			ultimo = primero;
			return this;
		}
		
	}
	
	public Lista insertarNodo(int entrada, int nodo)
	{
		Nodo anterior = buscarDato(nodo);
		Nodo nuevo;
		
		if(anterior != null)
		{
			nuevo = new Nodo(entrada);
			nuevo.setEnlace(anterior.getEnlace());
			anterior.setEnlace(nuevo);
		}
		
		return this;
	}
	
	public Lista insertarPosicion(int entrada, int posicion)
	{
		Nodo nuevo;
		
		if(buscarExistenciaPosicion(posicion))
		{
			int i;
			Nodo indice = primero;

			for(i = 1; (indice != null) && (i<posicion); i++)
			{
				indice = indice.getEnlace();
			}
			
			nuevo = new Nodo(entrada);
			nuevo.setEnlace(indice.getEnlace());
			indice.setEnlace(nuevo);
		}
		
		return this;
	}
	
	public void eliminar(int salida)
	{
		Nodo actual, anterior;
		boolean encontrado;
		
		actual = primero;
		anterior = null;
		encontrado = false;
		
		while((actual != null) && (encontrado == false))
		{
			if(actual.getDato() == salida)
			{
				encontrado = true;
			}
			
			if(encontrado == false)
			{
				anterior = actual;
				actual = anterior.getEnlace();
			}
		}
		
		if(actual != null)
		{
			if(actual == primero)
			{
				primero = actual.getEnlace();
			}
			else
			{
				anterior.setEnlace(actual.getEnlace());
			}
		}
	}
	
	public boolean buscarExistenciaPosicion(int posicion)
	{
		int i;
		Nodo indice = primero;

		for(i = 1; (indice != null) && (i<posicion); i++)
		{
			indice = indice.getEnlace();
		}
		
		if(indice != null)
		{
			return true;
		}
		
		return false;
		
	}
	
	public Nodo buscarDato(int dato)
	{
		Nodo buscado;
		
		for(buscado = primero; buscado != null; buscado = buscado.getEnlace())
		{
			if(buscado.getDato() == dato)
			{
				return buscado;
			}
		}
		
		return null;
	}
	
	public Lista insertarFinal(int pdato)
	{
		Nodo ulti;
		ulti = new Nodo(pdato);
		if(ultimo != null)
		{
			ultimo.setEnlace(ulti);
			ultimo = ulti;
			return this;
		}
		else
		{
			primero = ulti;
			ultimo = ulti;
			return this;
		}
		
	}
	
	public void visualizar()
	{
		Nodo n;
		 int k = 0;
		 n = primero;
		 while (n != null)
		 {
		 System.out.print(n.getDato() + " ");
		 n = n.getEnlace();
		 k++;
		 System.out.print( (k%15 != 0 ? " " : "\n"));
		 }
		 
		 System.out.println();
	}

}
