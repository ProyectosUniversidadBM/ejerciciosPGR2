package listaEnlazadaSimple;

public class Principal {

	public static void main(String[] args) {
		Lista lista = new Lista();
		
		for (int i = 25; i > 0; i--) {
			lista.insertarComienzo(i);
		}
		
		for (int i = 26; i < 50; i++) {
			lista.insertarFinal(i);
		}
		
		System.out.println("\n"); 
		
	
		lista.visualizar();
		
		System.out.println("--------------------------------------------------------------");
		
		lista.insertarPosicion(77, 2);
		
		lista.insertarNodo(999, 77);
		
		lista.eliminar(999);
		
		lista.visualizar();

	}

}
